
#include <stdio.h>
int cube(int n)
{
    if (n == 0)
    {
        return 0;
    }
    else
    {
        return n * n * n + cube(n - 1);
    }
}
int main()
{
    int n;
    printf("Input number of terms : ");
    scanf("%d", &n);
    printf("Number is : %d and cube of the %d is :%d", n, n, cube(n));
    return 0;
}
